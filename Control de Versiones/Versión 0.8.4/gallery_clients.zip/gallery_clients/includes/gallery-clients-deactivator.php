<?php
require_once GC_PLUGIN_DIR .'/../../../wp-config.php';
// Clientes

?>
